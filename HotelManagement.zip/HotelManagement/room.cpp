#include "room.h"
#include <iostream>

using namespace std;




int Room::getDailyRate() const
{
    return dailyRate;
}

int Room::getExtraExpenses() const
{
    return extraExpenses;
}

Room::Room(int number, int rate) {
    roomNumber = number;
    guestName = "";
    dailyRate = rate;
    isOccupied = false;
    extraExpenses = 0;
}


void Room::checkIn(const string& name) {
    if (!isOccupied) {
        guestName = name;
        isOccupied = true;         
    } else {
        // Oda boş değil kiralama yapılmıyor
    }
}

void Room::checkOut(int days) {
    if (isOccupied) {
        int totalCost = (days * dailyRate) + extraExpenses;
        guestName = "";
        isOccupied = false;
        extraExpenses = 0;
    } else {
        // Oda zaten boş, check-out yapılamaz
    }
}


void Room::addExtraExpense(int amount) {
    if (isOccupied) {
        extraExpenses += amount;
    }
}


int Room::getRoomNumber() {
    return roomNumber;
}


bool Room::isRoomOccupied() {
    return isOccupied;
}


string Room::getGuestName() const
{
    return guestName;
}
