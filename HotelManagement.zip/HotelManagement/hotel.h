#ifndef HOTEL_H
#define HOTEL_H

#include "room.h"
#include <vector>

using namespace std;



class Hotel
{
private:
    static Hotel* instance;   // declare
    vector<Room> rooms;

    Hotel();  // Private constrcutor for Singleton pattern


public:
    static Hotel* getInstantance();

    Room* findRoom(int roomNumber);

    ~Hotel();
};

#endif // HOTEL_H
