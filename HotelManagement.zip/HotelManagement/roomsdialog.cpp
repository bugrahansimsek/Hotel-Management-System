#include "roomsdialog.h"
#include "hotel.h"
#include "ui_roomsdialog.h"
#include "hotel.h"
#include "detailsdialog.h"
#include "checkoutdetailsdialog.h"

RoomsDialog::RoomsDialog(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::RoomsDialog)
{
    ui->setupUi(this);

    // Butonları odaların doluluk durumuna göre renklendir
    colorRoomButtons(101, ui->pushButton101);
    colorRoomButtons(102, ui->pushButton102);
    colorRoomButtons(103, ui->pushButton103);
    colorRoomButtons(201, ui->pushButton201);
    colorRoomButtons(202, ui->pushButton202);

}


void RoomsDialog::colorRoomButtons(int roomNo, QPushButton* button) {
    Hotel* hotel = Hotel::getInstantance();
    Room* room = hotel->findRoom(roomNo);
    if (room->isRoomOccupied()) {
        // Oda dolu, butonu kırmızıya boya
        button->setStyleSheet(
            "QPushButton { background-color: red; color: white; font-weight: bold;"
            " border-radius: 10px; font-size: 18 px }"

            "QPushButton:hover { background-color: darkred; }"
            );
    } else {
        // Oda dolu, butonu yeşile boya
        button->setStyleSheet(
            "QPushButton { background-color: green; color: white; font-weight: bold;"
            " border-radius: 10px; font-size: 18 px }"

            "QPushButton:hover { background-color: darkred; }"
            );
    }
}



void RoomsDialog::processButtonClicks(int roomNo, QPushButton* button) {
    Hotel* hotel = Hotel::getInstantance();
    Room* room = hotel->findRoom(roomNo);

    if (getIsCheckinPressed()) {     // Kullanıcı CheckIn işlemindeyse..
        if (!room->isRoomOccupied()) {
            setChosenRoom(roomNo);
            DetailsDialog* detailsDialog = new DetailsDialog(this);
            auto ret = detailsDialog->exec();            

            if (ret == QDialog::Accepted)
            {
                qDebug() << "Ok tiklandi!";
                room->checkIn(getCustomerName().toStdString());
                colorRoomButtons(roomNo, button);
            } else {
                qDebug() << "Cancel tiklandi!";
            }

            detailsDialog->deleteLater();
        }
    } else {   // Kullanıcı CheckOut işlemindeyse..
        if (room->isRoomOccupied()) {
            setChosenRoom(roomNo);
            CheckOutDetailsDialog* checkoutDetailsDialog = new CheckOutDetailsDialog(this);
            auto ret = checkoutDetailsDialog->exec();            

            if (ret == QDialog::Accepted)
            {
                qDebug() << "Check out tiklandi!";
                room->checkOut(checkoutDetailsDialog->getTotalDays());
                colorRoomButtons(roomNo, button);
            } else {
                qDebug() << "Cancel tiklandi!";
            }

            checkoutDetailsDialog->deleteLater();
        }
    }
}

bool RoomsDialog::getIsCheckinPressed() const
{
    return isCheckinPressed;
}

void RoomsDialog::setIsCheckinPressed(bool newIsCheckinPressed)
{
    isCheckinPressed = newIsCheckinPressed;
}


RoomsDialog::~RoomsDialog()
{
    delete ui;
}

void RoomsDialog::on_pushButtonOk_clicked()
{    
    accept();
}



void RoomsDialog::on_pushButton101_clicked()
{
    processButtonClicks(101, ui->pushButton101);
}

QString RoomsDialog::getCustomerName() const
{
    return customerName;
}

void RoomsDialog::setCustomerName(const QString &newCustomerName)
{
    customerName = newCustomerName;
}


int RoomsDialog::getChosenRoom() const
{
    return chosenRoom;
}

void RoomsDialog::setChosenRoom(int newChosenRoom)
{
    chosenRoom = newChosenRoom;
}




void RoomsDialog::on_pushButton102_clicked()
{
    processButtonClicks(102, ui->pushButton102);
}


void RoomsDialog::on_pushButton103_clicked()
{
    processButtonClicks(103, ui->pushButton103);
}


void RoomsDialog::on_pushButton201_clicked()
{
    processButtonClicks(201, ui->pushButton201);
}


void RoomsDialog::on_pushButton202_clicked()
{
    processButtonClicks(202, ui->pushButton202);
}

