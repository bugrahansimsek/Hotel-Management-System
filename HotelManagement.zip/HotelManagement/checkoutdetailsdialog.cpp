#include "checkoutdetailsdialog.h"
#include "ui_checkoutdetailsdialog.h"
#include "roomsdialog.h"
#include "hotel.h"
#include "room.h"

CheckOutDetailsDialog::CheckOutDetailsDialog(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::CheckOutDetailsDialog)
{
    ui->setupUi(this);

    RoomsDialog* parentDialog = dynamic_cast<RoomsDialog*>(parent);
    int roomNo = parentDialog->getChosenRoom();
    setCurrentRoomNo(roomNo);
    QString str = QString::number(roomNo);
    ui->label->setText(str);


    Hotel* hotel = Hotel::getInstantance();
    Room* room = hotel->findRoom(roomNo);
    QString strCustomerName = QString::fromStdString(room->getGuestName());
    ui->lineEdit->setText(strCustomerName);

}

CheckOutDetailsDialog::~CheckOutDetailsDialog()
{
    delete ui;
}

int CheckOutDetailsDialog::getTotalDays() const
{
    return totalDays;
}

void CheckOutDetailsDialog::setTotalDays(int newTotalDays)
{
    totalDays = newTotalDays;
}

void CheckOutDetailsDialog::on_pushButton_clicked()
{
    // ui->lineEditDays->text()
    bool ok;
    int days = ui->lineEditDays->text().toInt(&ok);

    if (ok) {
        Hotel* hotel = Hotel::getInstantance();
        Room* room = hotel->findRoom(getCurrentRoomNo());
        int totalFee = days * room->getDailyRate() + room->getExtraExpenses();
        ui->lineEditFee->setText(QString::number(totalFee));

    } else {
        // Kullanıcı days kutusuna sayı girmedi...
    }
}

int CheckOutDetailsDialog::getCurrentRoomNo() const
{
    return currentRoomNo;
}

void CheckOutDetailsDialog::setCurrentRoomNo(int newCurrentRoomNo)
{
    currentRoomNo = newCurrentRoomNo;
}


void CheckOutDetailsDialog::on_pushButtonOk_clicked()
{
    bool ok;
    int days = ui->lineEditDays->text().toInt(&ok);

    if (ok) {
        setTotalDays(days);
        accept();
    } else {
        // Kullanıcı Ok tıkladı ancak gün sayısı boş olduğu için checkout yapılamaz
        reject();
    }
}


void CheckOutDetailsDialog::on_pushButtonCancel_clicked()
{
    reject();
}

