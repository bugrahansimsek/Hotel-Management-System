#include "hotel.h"
#include <QDebug>
using namespace std;

Hotel* Hotel::instance = nullptr;  // initialization


Hotel::Hotel() {
    Room r1(101, 250);   // push_back: Önce nesne oluşturulur sonra vektöre eklenir
    rooms.push_back(r1);   // Burada kopyalam işlemi gerçekleştirilir

    Room r2(102, 250);
    rooms.push_back(r2);

    // emplace_back : Nesnyei doğrudan vektör içinde oluşturur
    rooms.emplace_back(103, 250);  // Kopyalama yok, argümanlar doğrudan iletilir
    rooms.emplace_back(201, 250);

    rooms.emplace_back(202, 500);  // Suite room
}



Hotel* Hotel::getInstantance() {
    if (instance == nullptr) {
        instance = new Hotel();
    }
    return instance;
}


Room* Hotel::findRoom(int roomNumber) {
    for (auto& room : rooms) {
        if (room.getRoomNumber() == roomNumber) {
            return &room;
        }
    }
    return nullptr;
}


Hotel::~Hotel() {
    delete instance;
}
